package com.example.activity_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActivityTrackerApplicationTests {

    @Test
    void contextLoads() {
    }

}
