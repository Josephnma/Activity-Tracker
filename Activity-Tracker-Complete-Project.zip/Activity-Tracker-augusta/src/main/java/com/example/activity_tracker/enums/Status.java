package com.example.activity_tracker.enums;

public enum Status {
    PENDING,
    IN_PROGRESS,
    DONE
}
